
#ifdef __cplusplus
extern "C" {
#endif

void board26k_reset(const NP2CFG *pConfig);
void board26k_bind(void);

#ifdef __cplusplus
}
#endif

