
#ifdef __cplusplus
extern "C" {
#endif

void board118_reset(const NP2CFG *pConfig);
void board118_bind(void);

#ifdef __cplusplus
}
#endif

