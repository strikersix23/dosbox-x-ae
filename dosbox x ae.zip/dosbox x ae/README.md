For instructions on how to use FreeBox / DosBox Turbo, please see:

  https://sites.google.com/site/dosboxturbo/

If you are totally new to DOS emulation on Android, please start with the Beginners Guide:

  https://sites.google.com/site/dosboxturbo/home/beginning-dosbox-turbo-for-newbies

Compilation Details:

An android.mk file is supplied for compilation with the Android NDK.  The compilation has only been 
tested on the Android r8 NDK. 
  
Required Dependencies:
* SlidingMenu
* ActionBarSherlock

Optional Dependencies:
* Android SDL Libraries (sdl, sdl_net, sdl_sound)
* mt32 emu
