
function hello ()
  print("Hello world again\n")
end

print("Hello world\n")

a = 3
print(a)

a = a + 3
print(a)

function func1 (x)
    return x * 111
end

hello()

print(func1(1))
print(func1(2))
print(func1(7))

reg_c_function1()
reg_c_function2(42)
reg_c_function2("This is a string")
print(reg_c_function3())

print("That's all\n")

